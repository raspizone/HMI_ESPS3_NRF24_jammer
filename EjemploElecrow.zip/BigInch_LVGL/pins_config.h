#pragma once

#define LCD_H_RES 800
#define LCD_V_RES 480
